    <footer>
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> Fiona Organics. Nature's Best for You.</p>
        </div>
    </footer>

    <script src="assets/js/main.js"></script>
</body>
</html>
